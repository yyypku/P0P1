// chatserver.cpp
#include "chatserver.h"
#include "ui_chatserver.h"
#include <QTextStream>
#include <QNetworkInterface>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QString>
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QDebug>


// 构造函数
ChatServer::ChatServer(QWidget *parent)
    : QWidget(parent), ui(new Ui::ChatServer), server(new QTcpServer(this))
{
    ui->setupUi(this);

    // 连接服务器的新连接信号到槽函数
    connect(server, &QTcpServer::newConnection, this, &ChatServer::newConnection);

    // 尝试监听端口1234上的所有地址
    if (!server->listen(QHostAddress::Any, 1234)) {
        ui->log->append("Server could not start!");
    } else {
        ui->log->append("Server started...");

        // 获取所有网络接口的IP地址
        QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
        for (const QHostAddress &ipAddress : ipAddressesList) {
            if (ipAddress != QHostAddress::LocalHost && ipAddress.toIPv4Address()) {
                QString ip = ipAddress.toString();
                // 过滤局域网IP地址
                if (ip.startsWith("10.") || ip.startsWith("192.168.") ||
                    (ip.startsWith("172.") && ip.section('.', 1, 1).toInt() >= 16 && ip.section('.', 1, 1).toInt() <= 31)) {
                    ui->log->append("Server IP Address: " + ip);
                }
            }
        }
    }
}

// 析构函数
ChatServer::~ChatServer()
{
    delete ui;
}

QJsonObject ChatServer::jsonToData(const QString& jsonString) {
    // 将QString转换为QByteArray
    QByteArray jsonData = jsonString.toUtf8();

    // 将QByteArray解析为JSON文档
    QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonData);

    // 将JSON文档转换为JSON对象
    QJsonObject jsonObj = jsonDoc.object();

    return jsonObj;
}

QString ChatServer::server_Send_p0p1_Msg_ToJson(const QString& p0p1_host,const QJsonArray& text) {
    // 创建JSON对象
    QJsonObject jsonObj;
    jsonObj["mode"] = "p0p1";
    jsonObj["p0p1_host"] = p0p1_host;
    //jsonObj["num_msg"] = num_msg;
    jsonObj["text"] = text;

    // 将JSON对象转换为JSON文档
    QJsonDocument jsonDoc(jsonObj);

    // 将JSON文档转换为QString（JSON字符串）
    QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);

    return jsonString;
}

QString ChatServer::server_Send_Friend_Msg_ToJson(const QString& opp_id,const QString& text) {
    // 创建JSON对象
    QJsonObject jsonObj;
    jsonObj["mode"] = "friend";
    jsonObj["opp_id"] = opp_id;
    jsonObj["text"] = text;

    // 将JSON对象转换为JSON文档
    QJsonDocument jsonDoc(jsonObj);

    // 将JSON文档转换为QString（JSON字符串）
    QString jsonString = jsonDoc.toJson(QJsonDocument::Compact);

    return jsonString;
}

void ChatServer::appendJsonObjectToFile(const QJsonObject& jsonObject, const QString& p0p1_host) {
    QDir currentDir=QDir::current();
    QString dirPath="p0p1_text";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return;
    }
    QString p0p1TextPath ="p0p1_text/"+ p0p1_host +".json";
    QFile file(p0p1TextPath);
    if (!file.open(QIODevice::Append)) {
        qWarning("Couldn't open the file for appending.");
        return;
    }


    QJsonDocument jsonDoc(jsonObject);
    QByteArray jsonData = jsonDoc.toJson(QJsonDocument::Compact) + "\n";

    file.write(jsonData);
    file.close();
}

QList<QJsonObject> ChatServer::readJsonObjectsFromFile(const QString& p0p1_host) {
    QDir currentDir=QDir::current();
    QString dirPath="p0p1_text";
    if(!currentDir.exists(dirPath))
    {
        if(!currentDir.mkdir(dirPath))
            return {};
    }
    QString filePath = "p0p1_text/"+ p0p1_host +".json";
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning("Couldn't open the file for reading.");
        return {};
    }

    QList<QJsonObject> jsonObjects;
    while (!file.atEnd()) {
        QByteArray line = file.readLine().trimmed();
        if (!line.isEmpty()) {
            QJsonDocument jsonDoc = QJsonDocument::fromJson(line);
            if (jsonDoc.isObject()) {
                jsonObjects.append(jsonDoc.object());
            } else {
                qWarning("Invalid JSON format: %s", line.data());
            }
        }
    }

    file.close();
    return jsonObjects;
}



// 新连接槽函数
void ChatServer::newConnection()
{
    QTcpSocket *client = server->nextPendingConnection(); // 获取新连接的客户端
    clients << client; // 将客户端加入客户端列表

    // 连接客户端的信号到槽函数
    connect(client, &QTcpSocket::readyRead, this, &ChatServer::readMessage);
    connect(client, &QTcpSocket::disconnected, this, &ChatServer::clientDisconnected);

    ClientInfo info;
    info.socket = client;
    clientInfos << info; // 将新客户端信息加入列表

    ui->log->append("New client connected...");

    // 请求客户端的名称
}

// 读取消息槽函数
void ChatServer::readMessage()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender()); // 获取发送信号的客户端
    if (client) {
        QTextStream stream(client);
        QString message = stream.readAll().trimmed();
        ui->log->append(message);
        // 检查客户端是否已命名
        bool found = false;
        for (ClientInfo &info : clientInfos) {
            if (info.socket == client) {
                if (info.name.isEmpty()) {
                    info.name = message; // 将消息作为客户端的名称保存
                    ui->log->append("Client " + info.name + " connected.");
                    return;
                } else {
                    found = true;
                }
            }
        }

        if (found) {
            ui->log->append("Client: " + message);
            processMessage(message); // 处理原始json数据
        } else {
            ui->log->append("Error: Client not found.");
        }
    }
}
// 处理消息槽函数
void ChatServer::processMessage(const QString &message)
{
    QJsonObject json_msg = jsonToData(message);
    QString client_id = json_msg["client_id"].toString();
    QString mode = json_msg["mode"].toString();
    ui->log->append("Client: "+client_id);
    if(mode=="p0p1"){
        QString doo = json_msg["do"].toString();
        if(doo == "send"){
            QString p0p1_host = json_msg["p0p1_host"].toString();
            QString text = json_msg["text"].toString();
            QJsonObject single_message;
            single_message["client_id"]=client_id;
            single_message["text"]=text;
            appendJsonObjectToFile(single_message,p0p1_host);
        }
        else if(doo == "request"){
            QString p0p1_host = json_msg["p0p1_host"].toString();
            QJsonArray text;
            QList<QJsonObject> tmp = readJsonObjectsFromFile(p0p1_host);
            for (const QJsonObject &jsonObject : tmp) {
                text.append(jsonObject);
            }
            QString to_send = server_Send_p0p1_Msg_ToJson(p0p1_host,text);
            sendMessageToClient(to_send,client_id);
        }
    }
    else if(mode=="friend"){

    }
    else if(mode=="information"){

    }
}

// 客户端断开连接槽函数
void ChatServer::clientDisconnected()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender()); // 获取发送信号的客户端
    if (client) {
        for (int i = 0; i < clientInfos.size(); ++i) {
            if (clientInfos.at(i).socket == client) {
                ui->log->append("Client " + clientInfos.at(i).name + " disconnected.");
                clientInfos.removeAt(i); // 从客户端信息列表中移除
                break;
            }
        }
        clients.removeAll(client); // 从客户端列表中移除
        client->deleteLater(); // 延迟删除客户端对象
    }
}

// 发送消息给特定客户端
void ChatServer::sendMessageToClient(const QString &message, const QString &clientName)
{
    QTcpSocket* client = findClientByName(clientName); // 查找客户端
    if (client && client->state() == QAbstractSocket::ConnectedState) {
        QTextStream stream(client);
        stream << message;
        client->flush(); // 刷新流以确保消息发送
    }
}

// 根据名称查找客户端
QTcpSocket* ChatServer::findClientByName(const QString &name)
{
    for (const ClientInfo &info : clientInfos) {
        if (info.name == name) {
            return info.socket;
        }
    }
    return nullptr;
}

// 广播消息给所有客户端
void ChatServer::broadcastMessage(const QString &message)
{
    for (const ClientInfo &info : clientInfos) {
        if (info.socket->state() == QAbstractSocket::ConnectedState) {
            QTextStream stream(info.socket);
            stream << message;
            info.socket->flush(); // 刷新流以确保消息发送
        }
    }
}

/*
接口使用说明：

1. 启动服务器：
   创建 ChatServer 对象并显示它的界面。
   服务器会自动监听端口 1234 并处理新连接。

2. 发送消息给特定客户端：
   调用 sendMessageToClient(const QString &message, const QString &clientName) 方法，
   传递消息内容和客户端名称。

3. 广播消息给所有客户端：
   调用 broadcastMessage(const QString &message) 方法，传递消息内容。

4. 客户端连接和断开：
   客户端连接时，服务器会自动处理并请求客户端名称。
   客户端断开连接时，服务器会自动更新客户端列表。

5. 接收客户端消息：
   当客户端发送消息时，服务器会自动读取并处理消息。
*/
