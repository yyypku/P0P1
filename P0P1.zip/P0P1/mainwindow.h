#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

struct HoleInformation{
    QString pid;
    QString text;
    int reply{0}; //reply_num
    int likenum{0};
    QString time;
};

struct CommentInformation{
    QString cid;
    QString pid;
    QString text;
    QString time;
    QString tag;
    QString comment_id;
    QString name;
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QString usr_name;
    QString user_name;
    static QString message_str;
    static QString host_user_name_str;
    void saveFile();
    void openFile();

private slots:
    void on_btn_name_clicked();

    void on_btn_profile_clicked();

    void on_toolButton_2_clicked();

    void on_btn_changetags_clicked();

    void on_toolButton_3_clicked();

    void on_toolButton_4_clicked();

    void on_toolButton_5_clicked();

    void on_toolButton_6_clicked();

    void on_toolButton_7_clicked();

    void on_toolButton_8_clicked();

    void on_toolButton_9_clicked();

    void on_toolButton_10_clicked();

    void on_toolButton_11_clicked();

    void on_toolButton_12_clicked();

    void on_pushButton_clicked();

    //void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    //void on_pushButton_4_clicked();

    //void on_pushButton_5_clicked();

    //void on_pushButton_4_pressed();

    //void on_pushButton_6_clicked();

    void on_lastpage_clicked();

    void on_nextpage_clicked();

    void on_lineEdit_4_editingFinished();

    void on_lineEdit_4_returnPressed();

private:
    HoleInformation getHoleReplyFromTreehole(const QString& hole_id);
    QList<CommentInformation> getCommentReplyFromTreehole(const QString& hole_id);
    QList<HoleInformation> getHoles(int page,int limit);
    Ui::MainWindow *ui;
    QTcpSocket *socket;
    QString authToken; // 保存认证Token
    QString authTokenPath = "authtoken/auth_token.txt";
    HoleInformation responseDatatoHoleInformation(const QByteArray &responseData);
    QList<HoleInformation> responseDatatoHolesInformation(const QByteArray &responseData);
    QList<CommentInformation> responseDatatoCommentInformation(const QByteArray &responseData);
    //int responseDatatoNewestHolenum(const QByteArray &responseData);
    void printHoleInformation();
public:
    bool readAuthTokenFromFile();
};
#endif // MAINWINDOW_H
