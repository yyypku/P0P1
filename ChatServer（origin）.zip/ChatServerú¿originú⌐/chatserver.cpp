#include "chatserver.h"
#include "ui_chatserver.h"
#include <QTextStream>
#include <QNetworkInterface>

ChatServer::ChatServer(QWidget *parent)
    : QWidget(parent), ui(new Ui::ChatServer), server(new QTcpServer(this))
{
    ui->setupUi(this);

    connect(server, &QTcpServer::newConnection, this, &ChatServer::newConnection);

    if (!server->listen(QHostAddress::Any, 1234)) {
        ui->log->append("Server could not start!");
    } else {
        ui->log->append("Server started...");

        // 获取并显示服务器的私有IP地址
        QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
        for (int i = 0; i < ipAddressesList.size(); ++i) {
            QHostAddress ipAddress = ipAddressesList.at(i);
            if (ipAddress != QHostAddress::LocalHost && ipAddress.toIPv4Address()) {
                QString ip = ipAddress.toString();
                if (ip.startsWith("10.") || ip.startsWith("192.168.") ||
                    (ip.startsWith("172.") && ip.section('.', 1, 1).toInt() >= 16 && ip.section('.', 1, 1).toInt() <= 31)) {
                    ui->log->append("Server IP Address: " + ip);
                }
            }
        }
    }
}

ChatServer::~ChatServer()
{
    delete ui;
}

void ChatServer::newConnection()
{
    QTcpSocket *client = server->nextPendingConnection();
    clients << client;

    connect(client, &QTcpSocket::readyRead, this, &ChatServer::readMessage);
    connect(client, &QTcpSocket::disconnected, this, &ChatServer::clientDisconnected);

    ui->log->append("New client connected...");
}

void ChatServer::readMessage()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender());
    if (client) {
        QTextStream stream(client);
        QString message = stream.readAll();
        ui->log->append("Client: " + message);
        broadcastMessage(message);
    }
}

void ChatServer::clientDisconnected()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender());
    if (client) {
        clients.removeAll(client);
        client->deleteLater();
        ui->log->append("Client disconnected...");
    }
}

void ChatServer::broadcastMessage(const QString &message)
{
    for (QTcpSocket *client : clients) {
        if (client->state() == QAbstractSocket::ConnectedState) {
            QTextStream stream(client);
            stream << message;
            client->flush();
        }
    }
}
