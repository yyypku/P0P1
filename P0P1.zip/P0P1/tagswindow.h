#ifndef TAGSWINDOW_H
#define TAGSWINDOW_H
#include <QPlainTextEdit>

#include <QWidget>

namespace Ui {
class tagswindow;
}

class tagswindow : public QWidget
{
    Q_OBJECT

public:
    explicit tagswindow(QPlainTextEdit *txtEdit_,QWidget *parent = nullptr);
    ~tagswindow();
    void output();
    void open();
    void save();

private slots:
    void on_toolButton_recommend_clicked();

    void on_toolButton_personality_clicked();

    void on_toolButton_sports_clicked();

    void on_toolButton_game_clicked();

    void on_toolButton_love_clicked();

    void on_toolButton_entertainment_clicked();

    void on_toolButton_food_clicked();

    void on_pushButton_64_clicked();

private:
    Ui::tagswindow *ui;
    QPlainTextEdit *txtEdit;
};

#endif // TAGSWINDOW_H
