#ifndef P0P1_CLIENT_H
#define P0P1_CLIENT_H

#include <QWidget>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonDocument>

namespace Ui {
class P0P1_Client;
}

class P0P1_Client : public QWidget
{
    Q_OBJECT

public:
    explicit P0P1_Client(QString user_name,QString other_user_name,QString usr_name,QString other_name,QTcpSocket *socket_,QWidget *parent = nullptr);
    ~P0P1_Client();
    QString client_user_name;
    QString opp_user_name;
    QString client_name;
    QString opp_name;
    QString client_Send_p0p1_Msg_ToJson(const QString& client_id, const QString& p0p1_host, const QString& text);
    QString client_Request_p0p1_Msg_ToJson(const QString& client_id, const QString& p0p1_host);
    QJsonObject jsonToData(const QString& jsonString);

signals:
    void dataReceived(QString opp_name,QString message);
private slots:
    // void connectToServer();
    void readMessage();
    void sendMessage();
    void displayError(QAbstractSocket::SocketError socketError);

    void on_toolButton_clicked();

private:
    Ui::P0P1_Client *ui;
    QTcpSocket *socket;
};

#endif // P0P1_CLIENT_H
