#include "treeholewindow.h"
#include "ui_treeholewindow.h"
#include <QScrollBar>
#include "mainwindow.h"

TreeholeWindow::TreeholeWindow(QString hole_index,QString hole_cont,QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TreeholeWindow)
{
    ui->setupUi(this);
    hole_id=hole_index;
    hole_content=hole_cont;
    ui->plainTextEdit->appendPlainText(hole_content);

}

TreeholeWindow::~TreeholeWindow()
{
    delete ui;
}

void TreeholeWindow::on_plainTextEdit_updateRequest(const QRect &rect, int dy)
{

}

