#ifndef CHATSERVER_H
#define CHATSERVER_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>

QT_BEGIN_NAMESPACE
namespace Ui { class ChatServer; }
QT_END_NAMESPACE

class ChatServer : public QWidget
{
    Q_OBJECT

public:
    ChatServer(QWidget *parent = nullptr);
    ~ChatServer();

private slots:
    void newConnection();
    void readMessage();
    void clientDisconnected();

private:
    void broadcastMessage(const QString &message);

    Ui::ChatServer *ui;
    QTcpServer *server;
    QList<QTcpSocket*> clients;
};

#endif // CHATSERVER_H
